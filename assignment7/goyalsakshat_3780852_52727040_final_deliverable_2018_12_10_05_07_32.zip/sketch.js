/*

the logo was based on a branding project that I worked on
before college. for better context, please refer the image on 
the following link. 

https://drive.google.com/open?id=1FH871QYNVbnUiHCDAAqASOtMUwOOwue2

*/


// Colours

var backgroundColour_Dark = 30;
var backgroundColour_Light = 250;
var transparency = 0;

var logoColour_1 = backgroundColour_Dark;
var logoColour_2 = 200;

// Timings

var logoStartPoint = 20;
var hrtStrokeStartPoint = logoStartPoint + logoColour_2 + 10;
var startPointforbottle = hrtStrokeStartPoint + 80;
var lastScreenStartPoint = startPointforbottle + 500;

// Positions

var logoPositionX = 420;
var logoPositionY = 100;


// Positions for the heartStrokes

var x1 = 51;
var y1 = 51;
var x2 = 51;
var y2 = 51;
var x3 = 108;
var y3 = 58;
var x4 = 108;
var y4 = 58;

// additional variables

var bottleStrokeWeight = 0.25;
var logoScaleFactor = 0.7;

// 

function setup() {
  createCanvas(600, 300);
  frameRate(45);

  background(backgroundColour_Dark);

}


function draw() {

  /*
  
  the order in which you see the functions playout is
  1. draw logo
  2. draw Bottles
  3. last screen
  
  */

  drawLogo();
  lastScreen(lastScreenStartPoint);
  drawBottles();

}


/*

The logo is essentially a shield with two strokes that 
form an abstracted heart. 

The drawLogo() function consisits of two parts.

1. logoShape()

This draws the basic profile of the logo which is a shield.
This is drawn by creating a rectangle and masking it with an
organic shape to make the rectangle appear as a shield.

2. heartStrokes()

This is the funtion that draws the two strokes that form 
the second part of the logo.

*/

function drawLogo() {
  push();

  if (frameCount >= logoStartPoint) {
    logoShape(logoPositionX, logoPositionY);
  }

  if (frameCount >= (hrtStrokeStartPoint)) {
    heartStrokes(logoPositionX + 20, logoPositionY + 20, (frameCount - hrtStrokeStartPoint));
  }
  pop();
}



function logoShape(logoX, logoY) {

  if (frameCount >= 200) return;

  // the return function was used to stop the function from 
  // running after a certain point to avoid overlapping 
  // frames with the last screen.

  push();
  noStroke();

  translate(logoX, logoY);
  fill(logoColour_1);

  if (logoColour_1 < logoColour_2) {
    logoColour_1 = logoColour_1 + 0.5;
  }


  scale(logoScaleFactor);

  // the scale function was an addition at the last moment
  // in order to get a decent proportion.

  rect(20, 20, 135, 162);

  fill(backgroundColour_Dark);

  // masking shape

  beginShape();

  curveVertex(0, 0);
  curveVertex(0, 0);
  curveVertex(19.63, 0);
  curveVertex(20, 20);
  curveVertex(20, 45);
  curveVertex(20, 90);
  curveVertex(20, 123.8);
  curveVertex(24.25, 138.35);
  curveVertex(33.8, 152.9);
  curveVertex(49.5, 167.44);
  curveVertex(87.5, 182);
  curveVertex(125.45, 167.44);
  curveVertex(141.2, 152.9);
  curveVertex(150.9, 138.35);
  curveVertex(155, 123.8);
  curveVertex(155, 90);
  curveVertex(155, 45);
  curveVertex(155, 20);
  curveVertex(155, 0);
  curveVertex(175, 0);
  curveVertex(175, 202);
  curveVertex(0, 202);
  curveVertex(0, 0);
  curveVertex(0, 0);

  endShape();
  pop();

}




function heartStrokes(PositionX, PositionY, iter_stroke) {

  if (frameCount >= 800) return;

  // the return function was used to stop the function from 
  // running after a certain point to avoid overlapping 
  // frames with the last screen.


  push();

  translate(PositionX - 6.5, PositionY - 6.5)

  // The (- 6.5) was added later on along with 
  // the scale function to match the location
  // of the strokes with respect to the logo shape

  scale(logoScaleFactor);

  // stroke 1 length = 36
  // stroke 2 length = 72

  strokeWeight(27)
  strokeCap(SQUARE);
  stroke(backgroundColour_Dark);
  line(x1, y1, x2, y2);
  line(x3, y3, x4, y4);

  // move x2 to 25 and y2 to 77
  // move x4 to 58 and y4 to 108

  if ((x2 > 25) && (y2 < 77)) {
    x2--;
    y2++;
  }
  if ((x4 > 58) && (y4 < 108) && (iter_stroke > 20)) {
    x4--;
    y4++;
  }
  pop();
}



/*

While drawing the bottles, I wanted the strokes to follow
a defined path. I started off with if/else statements 
but did not get too far with it. 

I had to get some help from a relative. The following is a 
smaller sample that I worked on to understand the concept.

________

var iter = 0;

function setup() {
  createCanvas(90, 90);
  background(220);
}

function draw() {
  translate(20, 20);
  if (iter < 200) iter++;
  var x, y;
  if (iter < 50) {
    x = iter;
    y = 0;
  } else if (iter < 100) {
    x = 50;
    y = iter - 50;
  } else if (iter < 150) {
    x = 150 - iter;
    y = 50;
  } else {
    x = 0;
    y = 200 - iter;
  }

  fill(0);
  rectMode(CENTER);
  ellipse(x, y, 5, 5);

}

_________

The basic idea is that, while drawing a square of 50 x 50, 
the process can be divided into 200 iterations in which at each
iteration, an ellipse is drawn which results to a square being 
drawn.

the 200 iterations can be divided into 4 parts, where for the
1st 50 (0 to 50) iterations, y is 0 and x = iteration
2nd 50 (50 to 100) iterations, x is 0 and y = (iteration - 50)
3rd 50 (100 - 150) iterations, y is 50 and x = (150 - iteration)
4th 50 (150 - 200) iterations, x is 50 and y = (200 - iteration)

I took the same concept, but increased the number of iterations
that allowed for 3 rectangles to be drawn within certain domains
of the iterations. I used the frameCount in place for iterations.

So, the  current framecount - the startPoint frameCount becomes 
"iter". 

The x and y variables are the coordinates for the ellipses of the 
3 rectangles.


*/


function drawBottles() {

  if (frameCount >= 800) return;

  if (frameCount >= startPointforbottle) {
    bottle(50, 150, frameCount - startPointforbottle);
  }
  if (frameCount >= startPointforbottle + 80) {
    bottle(50, 0, frameCount - (startPointforbottle + 80));
  }
  if (frameCount >= (startPointforbottle + 160)) {
    bottle(50, 0, frameCount - (startPointforbottle + 160));
  }
  if (frameCount >= (startPointforbottle + 240)) {
    bottle(50, 0, frameCount - (startPointforbottle + 240));
  }

}

function bottle(start_X1, start_Y1, iter) {

  translate(start_X1, start_Y1);

  // The x and y values for the top rectangle of the bottle
  // iter limit for 1st one is 37
  // adding 3.75 to all x values

  var x1;
  var y1;

  if (iter < 7.5) {
    x1 = iter + 3.75;
    y1 = 0;
  } else if (iter < 18.5) {
    x1 = 7.5 + 3.75;
    y1 = iter - 7.5;
  } else if (iter < 26) {
    x1 = 26 - iter + 3.75;
    y1 = 11;
  } else if ((iter > 26) && (iter < 37)) {
    x1 = 0 + 3.75;
    y1 = 37 - iter;
  }


  var x2;
  var y2;

  // The x and y values for the middle rectangle of the bottle
  // limit for 2nd one is 45
  // adding 13.6 to all y values

  if ((iter > 20) && (iter < 35)) {
    x2 = iter - 20;
    y2 = 0 + 13.6;
  } else if ((iter > 35) && (iter < 42.75)) {
    x2 = 15;
    y2 = iter - 35 + 13.6;
  } else if ((iter > 42.75) && (iter < 57.5)) {
    x2 = 57.5 - iter;
    y2 = 0 + 13.6;
  } else if ((iter > 57.5) && (iter < 65)) {
    x2 = 0;
    y2 = 65 - iter + 13.6;
  }

  // The x and y values for the bottom rectangle of the bottle
  // limit for 3rd one is 128

  var x3;
  var y3;

  // adding 23.5 to all y values

  if ((iter > 45) && (iter < 60)) {
    x3 = iter - 45;
    y3 = 0 + 23.5;
  } else if ((iter > 60) && (iter < 109)) {
    x3 = 15;
    y3 = iter - 60 + 23.5;
  } else if ((iter > 109) && (iter < 124)) {
    x3 = 124 - iter;
    y3 = 49 + 23.5;
  } else if ((iter > 124) && (iter < 173)) {
    x3 = 0;
    y3 = 173 - iter + 23.5;
  }


  fill(220);
  ellipseMode(CENTER);
  stroke(200);

  // ellipses for the bottle profiles

  ellipse(x1, y1, bottleStrokeWeight, bottleStrokeWeight);
  ellipse(x2, y2, bottleStrokeWeight, bottleStrokeWeight);
  ellipse(x3, y3, bottleStrokeWeight, bottleStrokeWeight);

  // ellipse for the spray nozzle

  ellipse(3.75 + 3.75, 4.5, 1.5, 1.5);

}


/*

The lastScreen is the simply to fade the canvas into a white 
background. It is a white rectangle that starts off with an
opacity level of 0 and keeps incrementing by 1. 

This is the reason for using the return funtion for the logo.

*/

function lastScreen(frameCountValue) {
  
  if (frameCount >= frameCountValue) {

    fill(backgroundColour_Light, transparency);
    if (transparency < 100) {
      transparency++;
    }
    noStroke();
    rect(0, 0, width, height)
  }

}